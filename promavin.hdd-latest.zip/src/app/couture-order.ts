export class CoutureOrder {
  constructor(
      public productId:string, 
      public customer:object
    ) { }
}
