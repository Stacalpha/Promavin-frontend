import { CoutureOrder } from './couture-order';

describe('CoutureOrder', () => {
  it('should create an instance', () => {
    expect(new CoutureOrder()).toBeTruthy();
  });
});
