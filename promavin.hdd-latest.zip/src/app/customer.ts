export class Customer {
  constructor() { }

  name:string = "";
  address:string = "";
  contact = {
    email: "", 
    phone: "",
  }
}
