import { Component, OnInit } from '@angular/core';
//import { Observable } from 'rxjs';

@Component({
  selector: 'app-showcase',
  templateUrl: './showcase.component.html',
  styleUrls: ['./showcase.component.css']
})
export class ShowcaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    scrollTo(0, 0);   
  }

  catalogue:Array<any> = this.getCatalogue();

  selectedProduct:any|string = 'custom';

  orderWindowDisplay:boolean = false;

  showOrderWindow(clickedProduct?:any|string):void {
    if (clickedProduct)
      this.selectedProduct = clickedProduct;
    
    this.orderWindowDisplay = true;  
  }

  closeOrderWindow():void {
    this.selectedProduct = 'custom';
    
    this.orderWindowDisplay = false;
  }

  getCatalogue():any[] { //ToDo:- returns :Observable<product>
    let baseUrl = "../../assets/images/product.cards";
    let count = 1;
    let catalogue:any[] = [];

    do {
      catalogue.push({ imgSrc: `${baseUrl}/${count}.jpg` });
      count++;
    } while (count <= 23);

    return catalogue;
  }
}
